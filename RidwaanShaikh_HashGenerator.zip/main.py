import hash_library
#IMPORTED THE HASH LIBRARY THAT HAS ALL THE FUNCTIONS.

# MADE THE MENU INTO A FUNCTION SO I CAN CALL IT EASILY IN A WHILE LOOP.
def menu():
    print("""
    ================================
            HASH GENERATOR
    ================================
    
    1. Generate MD5 Hash
    2. Generate SHA-1 Hash
    3. Generate SHA-256 Hash
    4. Generate SHA-512 Hash
    5. Exit
          """)
   
while True:
    menu()
    # USING TRY, EXCEPT BY USER INPUTS TO HANDLE ERRORS EFFICIENTLY AND GRACEFULLY.
    try:
        choice = int(input("Choose an option (1-5): "))
        if choice < 1 or choice > 5:
            print("Please enter a number between 1 and 5.")
        # USED 'CONTINUE' TO RUN BACK TO THE LOOP IF INPUT IS INVALID.
            continue
    except ValueError:
        print("Invalid. Please enter a number between 1 and 5.")
        continue
    
    # IF (CHOICE = 1), WE WILL CALL THE MD5 HASH GENERATE FUNCTION.
    if (choice == 1):
        # CALLING THE INPUT FUNCTION FIRST TO GET THE USERS INPUT.
        text_to_hash = hash_library.text_input()
        # CALLING THE HASH GENERATE FUNCTION TO TURN TEXT INTO A HASH.
        hashed_text = hash_library.generate_md5(text_to_hash)
        print(f"MD5 Hash: {hashed_text}")
        # CALLING THE SAVE HASH FUNCTION TO ASK USER IF THEY WANT TO SAVE. IF YES, IT WILL BE SAVED IN THE DATABASE.
        hash_library.save_hash(hashed_text)
        break
        
    # THE PROCESS ABOVE IS DONE ON ALL THE CHOICES BELOW.
        
    # IF (CHOICE = 2), WE WILL CALL THE SHA1 HASH GENERATE FUNCTION.                
    elif (choice == 2):
        text_to_hash = hash_library.text_input()
        hashed_text = hash_library.generate_sha1(text_to_hash)
        print(f"SHA1 Hash: {hashed_text}")
        hash_library.save_hash(hashed_text)
        break
        
    # IF (CHOICE = 3), WE WILL CALL THE SHA256 HASH GENERATE FUNCTION.         
    elif (choice == 3):
        text_to_hash = hash_library.text_input()
        hashed_text = hash_library.generate_sha256(text_to_hash)
        print(f"SHA256 Hash: {hashed_text}")
        hash_library.save_hash(hashed_text)
        break
        
    # IF (CHOICE = 4), WE WILL CALL THE SHA512 HASH GENERATE FUNCTION.    
    elif (choice == 4):
        text_to_hash = hash_library.text_input()
        hashed_text = hash_library.generate_sha512(text_to_hash)
        print(f"SHA521 Hash: {hashed_text}")
        hash_library.save_hash(hashed_text)
        break
        
    # IF (CHOICE = 5), WE WILL BREAK THE LOOP AND CLOSE THE PROGRAM.
    elif (choice == 5):
        print("Thank You For Using Hash Generator.")
        break
 