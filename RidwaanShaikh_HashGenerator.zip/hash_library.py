import hashlib
from datetime import datetime
# IMPORTED THE HASHLIB AND DATETIME LIBRARY

# SAVED THE DATE AND TIME INTO A EASY TO READ FORMAT.
now = datetime.now()
date_time = now.strftime("%Y-%m-%d %H:%M:%S")

def text_input():
    while True:
        # ASKS USER TO INPUT TEXT.
            text_to_hash = input("Enter text to hash: ")
            # IF THE TEXT IS EMPTY, IT WILL GIVE AN ERROR AND ASK USER TO RETRY.
            if not text_to_hash:
                print("Input is empty. Please enter text to Hash.")
                # IF THE USER HAS ANY NUMBERS OR SPECIAL CHARACTERS, IT WILL NOTIFY THE USER AND ASK THE USER TO RETRY.
            elif text_to_hash and text_to_hash.replace(" ","").isalpha():
                # RETURNS THE USER INPUT.
                return text_to_hash
            else:
                print("Only letters and spaces are allowed.")
                    
def save_hash(hashedText):
    while True:
        # ASKS USER IF THE USER WANTS TO SAVE THE HASHED TEXT AND INPUT IS SAVED IN LOWERCASE.
        choice = input("Would you like to save this hash? (y/n): ").strip().lower()
        try:
            if choice == 'y':
                # IF YES, DATA.TXT IS OPENED AND HASHED TEXT IS SAVED WITH THE DATE AND TIME.
                with open("data.txt","a") as file:
                    file.write(f"{hashedText}::{date_time}\n")
                    print("Hash saved successfully. Thank you.")
                    break
            elif choice == 'n':
                # IF NO, FOLLOWING PRINT IS SHOWN AND TEXT DOES NOT SAVE.
                print("Hash not saved. Thank you for using Hash Generator.")
                break
            else:
                print("Invalid input. Please enter y or n.")
        except PermissionError:
            print("Permission denied: You do not have permission for this action.")
            
def generate_md5(text):
    # TAKES THE TEXT AND TURNS IT INTO BYTE FORMAT.
    byte_text = text.encode()
    # TAKES THE BYTE.TEXT AND TURNS IT INTO A HASH.
    hash_text = hashlib.md5(byte_text)
    # RETURNS THE HASHED TEXT.
    return hash_text.hexdigest()

# THE FOLLOWING IS DONE FOR EVERY OTHER HASH BELOW.

def generate_sha1(text):
    byte_text = text.encode()
    hash_text = hashlib.sha1(byte_text)
    return hash_text.hexdigest()

def generate_sha256(text):
    byte_text = text.encode()
    hash_text = hashlib.sha256(byte_text)
    return hash_text.hexdigest()

def generate_sha512(text):
    byte_text = text.encode()
    hash_text = hashlib.sha512(byte_text)
    return hash_text.hexdigest()